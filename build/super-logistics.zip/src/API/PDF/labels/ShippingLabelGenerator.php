<?php

namespace BigTB\SL\API\PDF\Labels;

use SimplePie\Exception;

class ShippingLabelGenerator extends LabelGenerator {

	public int $bodyTextSize = 12;

	public function generate( array $labelInfo ): string|Exception {
		// We'll generate one page per piece
		$totalPages = (int) $labelInfo['total_pcs'];

		// If you do NOT want that initial blank page from the parent constructor,
		// you can remove it before looping:
		// $this->pdf->deletePage(1);

		for ( $currentPage = 1; $currentPage <= $totalPages; $currentPage ++ ) {
			// Add a new page for each piece
			// (If you removed the parent's AddPage, keep this one.)
			$this->pdf->AddPage();

			$this->writeLabel( $labelInfo, $currentPage, $totalPages );
		}

		// Output the PDF with all pages
		return $this->pdf->Output( 'label.pdf', 'S' );
	}

	private function writeLabel( array $labelInfo, int $currentPage, int $totalPages ): void {
		// Adjust margins smaller for A6 format (4x6). For example:
		$this->pdf->SetMargins( 5, 5, 5 );
		// Or skip if you prefer the defaults from the parent.

		// Use a slightly smaller base font for a 4x6 label
		$this->pdf->SetFont( 'helvetica', '', $this->bodyTextSize );

		// ------------------------------------------------------
		// 1) Draw the QR code in the upper-left
		// ------------------------------------------------------
		$qrCodeInfo = [
			'shipper'        => $labelInfo['shipper'],
			'exhibitor'      => $labelInfo['exhibitor'],
			'show_id'        => $labelInfo['show_id'],
			'zone_id'        => $labelInfo['zone_id'],
			'booth_id'       => $labelInfo['booth_id'],
			'carrier'        => $labelInfo['carrier'],
			'tracking'       => $labelInfo['tracking'],
			'street_address' => $labelInfo['street_address'],
			'city'           => $labelInfo['city'],
			'state'          => $labelInfo['state'],
			'zip'            => $labelInfo['zip'],
			'freight_type'   => $labelInfo['freight_type'],
			'total_pcs'      => $labelInfo['total_pcs'],
		];
		$qrCodeData = json_encode( $qrCodeInfo );
		// Coordinates and size for a 4x6. Adjust as needed.
		$qrX    = 5;
		$qrY    = 5;
		$qrSize = 30; // 30 mm square

		// 'QRCODE,M' or 'QRCODE,Q' depending on error correction desired
		$this->pdf->write2DBarcode( $qrCodeData, 'QRCODE,L', $qrX, $qrY, $qrSize, $qrSize, null, 'N' );

		// ------------------------------------------------------
		// 2) Print “(currentPage) of (totalPages)” to the right of the QR code
		// ------------------------------------------------------
		// Move “cursor” to the right of QR
		$this->pdf->SetFont( 'helvetica', '', 50 );  // Slightly smaller than the large label example
		$this->pdf->SetXY( $qrX + $qrSize + 5, $qrY + 5 );
		$this->pdf->Cell( 0, 8, $currentPage . ' of ' . $totalPages, 0, 1, 'L' );

		// ------------------------------------------------------
		// 3) “From:” section
		// ------------------------------------------------------
		$this->pdf->SetXY( $qrX, $qrY + $qrSize + 5 );
		$this->pdf->SetFont( 'helvetica', 'B', $this->bodyTextSize );
		$this->pdf->Cell( 0, 5, 'From:', 0, 1, 'L' );
		$this->pdf->SetFont( 'helvetica', '', $this->bodyTextSize );
		$fromLines = [
			$labelInfo['shipper'],
			$labelInfo['street_address'],
			$labelInfo['city'] . ', ' . $labelInfo['state'] . ' ' . $labelInfo['zip']
		];
		foreach ( $fromLines as $line ) {
			$this->pdf->Cell( 0, 4, $line, 0, 1, 'L' );
		}

		// ------------------------------------------------------
		// 4) “To:” section
		// ------------------------------------------------------
		$this->pdf->Ln( 3 );
		$this->pdf->SetFont( 'helvetica', 'B', $this->bodyTextSize );
		$this->pdf->Cell( 0, 5, 'To:', 0, 1, 'L' );
		$this->pdf->SetFont( 'helvetica', '', $this->bodyTextSize );

		// Hardcode Advance Warehouse Address
		$this->pdf->Cell( 0, 4, $labelInfo['exhibitor'], 0, 1, 'L' );
		$this->writeInfo( 'Care of', 'ThinkSTG Advance Warehouse', 17 );
		$toLines = [
			'751 West Warm Springs Rd. Ste. 140',
			'Henderson, NV, 89011',
			'702-251-8440'
		];
		foreach ( $toLines as $line ) {
			$this->pdf->Cell( 0, 4, $line, 0, 1, 'L' );
		}

		// ------------------------------------------------------
		// 5) Show / Zone / Booth
		// ------------------------------------------------------
		$this->pdf->Ln( 3 );
		$this->writeInfo( 'Show', $labelInfo['show']['name'], 14);
		$this->writeInfo( 'Zone', $labelInfo['zone']['name']);
		$this->writeInfo( 'Booth', $labelInfo['booth']['name'], 15 );

		// ------------------------------------------------------
		// 6) Carrier / Freight / Tracking
		// ------------------------------------------------------
		$this->pdf->Ln( 2 );
		$this->writeInfo( 'Carrier', $labelInfo['carrier'], 16 );

		$freightTypes = [ 'LTL', 'FTL', 'Small Pack' ];
		$this->writeInfo( 'Freight Type', $freightTypes[ $labelInfo['freight_type'] ], 28 );

		// Only show tracking if provided
		$trackingNumber = $labelInfo['tracking'][$currentPage - 1] ?? '';
		$this->writeInfo( 'Tracking / Pro #', $trackingNumber, 34 );

		// Done with this page
	}

	private function writeInfo( string $label, string|int $value, int $width = 12 ): void {
		// Bold Label
		$this->pdf->SetFont( 'helvetica', 'B', $this->bodyTextSize );
		$this->pdf->Cell( $width, 4, $label . ': ', 0, 0, 'L' );

		// Regular Text for info
		$this->pdf->SetFont( 'helvetica', '', $this->bodyTextSize );
		$this->pdf->Cell( $width, 4, $value, 0, 1, 'L' );
	}
}
