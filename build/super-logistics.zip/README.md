# Super Logistics

Super Logistics is a WordPress plugin that allows you to manage your logistics data in a simple and efficient way.

## Data Organization (engineering)

The plugin is organized in the following way:

### Entities

The following are considered the main entities of the plugin:
- clients
- shows

### Users

Users are stored in the wp_users table and are associated with entities through the sl_users_entities table.

